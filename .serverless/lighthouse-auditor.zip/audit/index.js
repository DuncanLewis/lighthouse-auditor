const launch = require('@serverless-chrome/lambda')

const handler = require('./b4hpyw7pvad___index.js')
const options = {"flags":["--window-size=1680x1050","--single-process","--data-path=/tmp/randompath1","--disk-cache-dir=/tmp/randompath2"]}

module.exports.handler = function ensureHeadlessChrome (event, context, callback) {
  (typeof launch === 'function' ? launch : launch.default)(options)
    .then((instance) => {
      handler.handler(event, context, callback, instance)
    })
    .catch((error) => {
      console.error(
        'Error occured in serverless-plugin-chrome wrapper when trying to ' +
          'ensure Chrome for handler() handler.',
        options,
        error
      )
    })
}