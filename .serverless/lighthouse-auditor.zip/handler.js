const launch = require('@serverless-chrome/lambda')

const handler = require('./ea7pirlp559___handler.js')
const options = {"flags":["--window-size=1680x1050","--hide-scrollbars","--ignore-certificate-errors","--headless","--disable-gpu","--no-sandbox","--homedir=/tmp/randompath0","--single-process","--data-path=/tmp/randompath1","--disk-cache-dir=/tmp/randompath2"]}

module.exports.audit = function ensureHeadlessChrome (
  event,
  context,
  callback
) {
  return (typeof launch === 'function' ? launch : launch.default)(options)
    .then(instance =>
      handler.audit(event, context, callback, instance))
    .catch((error) => {
      console.error(
        'Error occured in serverless-plugin-chrome wrapper when trying to ' +
          'ensure Chrome for audit() handler.',
        options,
        error
      )

      callback(error)
    })
}